/*
#include "pico/stdlib.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"


#define BUTTON_PIN 16
#define LED_PIN 15

// Definições de Handle
SemaphoreHandle_t xButtonSemaphore;
QueueHandle_t xQueue;

TaskHandle_t Task_Button;
TaskHandle_t Task_Led;



void gpio_callback(uint gpio, uint32_t events) {
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    xSemaphoreGiveFromISR(xButtonSemaphore, &xHigherPriorityTaskWoken);
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

// Tarefa do botão
void button_task(void *pvParameters) {
    uint8_t led_command = 1;

    while (1) {
        if (xSemaphoreTake(xButtonSemaphore, portMAX_DELAY) == pdTRUE) {
            // Enviar comando para a fila
            xQueueSend(xQueue, &led_command, portMAX_DELAY);
        }
    }
}

void led_task(void *pvParameters) {
    uint8_t led_command;

    while (1) {
        // Recebendo comando da fila
        if (xQueueReceive(xQueue, &led_command, portMAX_DELAY) == pdTRUE) {
            // Alternar estado do LED
            gpio_put(LED_PIN, !gpio_get(LED_PIN));
        }
    }
}

int main() {
    stdio_init_all();

    // Inicialização dos GPIOs
    gpio_init(BUTTON_PIN);
    gpio_set_dir(BUTTON_PIN, GPIO_IN);
    gpio_pull_up(BUTTON_PIN);

    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);

    // Criação do semáforo binário
    xButtonSemaphore = xSemaphoreCreateBinary();

    // Criação da QUEUE
    xQueue = xQueueCreate(10, sizeof(uint8_t));

    // Configuração da interrupção do botão
    gpio_set_irq_enabled_with_callback(BUTTON_PIN, GPIO_IRQ_EDGE_FALL, true, &gpio_callback);

    // Criação das tarefas
    xTaskCreate(button_task, "Button Task", 256, NULL, 1, &Task_Button);
    xTaskCreate(led_task, "LED Task", 256, NULL, 1, &Task_Led);

    // Inicialização do scheduler do FreeRTOS
    vTaskStartScheduler();

    // Loop infinito 
    while (1) {

    }
    return 0;
}

*/


#include "pico/stdlib.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"

// Definições de pinos
#define BUTTON_PIN 16
#define LED_PIN 15

// Handles do semáforo e fila
SemaphoreHandle_t xButtonSemaphore;
QueueHandle_t xQueue;

void gpio_callback(uint gpio, uint32_t events) {
    static uint32_t last_interrupt_time = 0;
    uint32_t interrupt_time = to_ms_since_boot(get_absolute_time());

    // Debounce: Ignorar interrupções que ocorrem dentro de 200 ms
    if (interrupt_time - last_interrupt_time > 200) {
        BaseType_t xHigherPriorityTaskWoken = pdFALSE;
        xSemaphoreGiveFromISR(xButtonSemaphore, &xHigherPriorityTaskWoken);
        portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
    }

    last_interrupt_time = interrupt_time;
}

void management_task(void *pvParameters) {
    uint8_t led_command = 1;

    while (1) {
        // Aguarda pelo semáforo (sinal da interrupção do botão)
        if (xSemaphoreTake(xButtonSemaphore, portMAX_DELAY) == pdTRUE) {
            // Aqui você pode adicionar mais lógica se necessário
            // Notifica a tarefa do botão
            xQueueSend(xQueue, &led_command, portMAX_DELAY);
        }
    }
}

void button_task(void *pvParameters) {
    uint8_t led_command;

    while (1) {
        // Aguarda pelo sinal da tarefa de gerenciamento
        if (xQueueReceive(xQueue, &led_command, portMAX_DELAY) == pdTRUE) {
            // Envia o comando para a fila
            xQueueSend(xQueue, &led_command, portMAX_DELAY);
        }
    }
}

void led_task(void *pvParameters) {
    uint8_t led_command;

    while (1) {
        // Recebe o comando da fila
        if (xQueueReceive(xQueue, &led_command, portMAX_DELAY) == pdTRUE) {
            // Alterna o estado do LED
            gpio_put(LED_PIN, !gpio_get(LED_PIN));
        }
    }
}

int main() {
    stdio_init_all();

    // Inicializar GPIOs
    gpio_init(BUTTON_PIN);
    gpio_set_dir(BUTTON_PIN, GPIO_IN);
    gpio_pull_up(BUTTON_PIN);
    gpio_set_irq_enabled_with_callback(BUTTON_PIN, GPIO_IRQ_EDGE_FALL, true, &gpio_callback);

    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);

    // Criar semáforo binário
    xButtonSemaphore = xSemaphoreCreateBinary();

    // Criar fila
    xQueue = xQueueCreate(10, sizeof(uint8_t));

    // Criar tarefas
    xTaskCreate(management_task, "Management Task", 256, NULL, 1, NULL);
    xTaskCreate(button_task, "Button Task", 256, NULL, 1, NULL);
    xTaskCreate(led_task, "LED Task", 256, NULL, 1, NULL);

    // Iniciar o scheduler do FreeRTOS
    vTaskStartScheduler();

    // Loop infinito (não deve chegar aqui)
    while (1) {
    }
    return 0;
}
